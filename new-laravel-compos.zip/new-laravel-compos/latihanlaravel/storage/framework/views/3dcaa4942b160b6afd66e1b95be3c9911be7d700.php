<?php $__env->startSection('judul'); ?>
pendaftaran
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos voluptatibus necessitatibus iusto, voluptatum voluptates, pariatur alias ullam rerum quae corporis ipsa aperiam qui deleniti recusandae dicta, assumenda veritatis ut facere.¸
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ang/Desktop/laravel/latihanlaravel/resources/views/halaman/daftar.blade.php ENDPATH**/ ?>