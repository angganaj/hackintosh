@extends('layout.master')

@section('judul')
pendaftaran
    
@endsection

@section('content')
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos voluptatibus necessitatibus iusto, voluptatum voluptates, pariatur alias ullam rerum quae corporis ipsa aperiam qui deleniti recusandae dicta, assumenda veritatis ut facere.¸
@endsection