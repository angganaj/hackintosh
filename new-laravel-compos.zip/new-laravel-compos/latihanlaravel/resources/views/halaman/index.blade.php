@extends('layout.master')

@section('judul')
    Halaman Utama
@endsection
    
@section('content')
    <a href="/pendaftaran">menuju pendaftara</a>
@endsection